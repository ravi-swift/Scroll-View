//
//  ViewController.swift
//  ScrollViewDemo
//
//  Created by Rp on 01/01/19.
//  Copyright © 2019 Rp. All rights reserved.
//

import UIKit


class ViewController: UIViewController {
    
    @IBOutlet var lbl : UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        lbl.font = UIFont.systemFont(ofSize: 20)
        lbl.numberOfLines = 0
        lbl.sizeToFit()
    }


}

